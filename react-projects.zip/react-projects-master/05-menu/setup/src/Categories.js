import React from "react";

const Categories = ({ categories, filter }) => {
  return (
    <div className="btn-container">
      {categories.map((i) => {
        return (
          <button key={i} className="filter-btn" onClick={() => filter(i)}>
            {i}
          </button>
        );
      })}
    </div>
  );
};

export default Categories;
